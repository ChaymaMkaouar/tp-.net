﻿namespace tp2_ex_3
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.Dg_Mot = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Btn_Vider = new System.Windows.Forms.Button();
            this.Btn_Supprimer = new System.Windows.Forms.Button();
            this.Btn_Recherche = new System.Windows.Forms.Button();
            this.Btn_Ajout = new System.Windows.Forms.Button();
            this.Btn_Nouveau = new System.Windows.Forms.Button();
            this.Txt_Mot = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Txt_Def = new System.Windows.Forms.RichTextBox();
            this.Mots = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Definitions = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Mot)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Dg_Mot
            // 
            this.Dg_Mot.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dg_Mot.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Mots,
            this.Definitions});
            this.Dg_Mot.Location = new System.Drawing.Point(30, 24);
            this.Dg_Mot.Name = "Dg_Mot";
            this.Dg_Mot.RowHeadersWidth = 51;
            this.Dg_Mot.RowTemplate.Height = 24;
            this.Dg_Mot.Size = new System.Drawing.Size(656, 135);
            this.Dg_Mot.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Dg_Mot);
            this.groupBox1.Location = new System.Drawing.Point(29, 241);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(727, 184);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Liste Mots / Défintion";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Btn_Vider);
            this.groupBox2.Controls.Add(this.Btn_Supprimer);
            this.groupBox2.Controls.Add(this.Btn_Recherche);
            this.groupBox2.Controls.Add(this.Btn_Ajout);
            this.groupBox2.Controls.Add(this.Btn_Nouveau);
            this.groupBox2.Controls.Add(this.Txt_Mot);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.Txt_Def);
            this.groupBox2.Location = new System.Drawing.Point(44, 24);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(681, 206);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Saisie de Mot / Définition";
            // 
            // Btn_Vider
            // 
            this.Btn_Vider.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Btn_Vider.Location = new System.Drawing.Point(535, 164);
            this.Btn_Vider.Name = "Btn_Vider";
            this.Btn_Vider.Size = new System.Drawing.Size(114, 27);
            this.Btn_Vider.TabIndex = 8;
            this.Btn_Vider.Text = "Vider";
            this.Btn_Vider.UseVisualStyleBackColor = false;
            this.Btn_Vider.Click += new System.EventHandler(this.Btn_Vider_Click);
            // 
            // Btn_Supprimer
            // 
            this.Btn_Supprimer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.Btn_Supprimer.Location = new System.Drawing.Point(535, 98);
            this.Btn_Supprimer.Name = "Btn_Supprimer";
            this.Btn_Supprimer.Size = new System.Drawing.Size(114, 60);
            this.Btn_Supprimer.TabIndex = 7;
            this.Btn_Supprimer.Text = "Supprimer un Mot";
            this.Btn_Supprimer.UseVisualStyleBackColor = false;
            this.Btn_Supprimer.Click += new System.EventHandler(this.Btn_Supprimer_Click);
            // 
            // Btn_Recherche
            // 
            this.Btn_Recherche.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_Recherche.Location = new System.Drawing.Point(535, 65);
            this.Btn_Recherche.Name = "Btn_Recherche";
            this.Btn_Recherche.Size = new System.Drawing.Size(114, 27);
            this.Btn_Recherche.TabIndex = 6;
            this.Btn_Recherche.Text = "Rechercher";
            this.Btn_Recherche.UseVisualStyleBackColor = false;
            this.Btn_Recherche.Click += new System.EventHandler(this.Btn_Recherche_Click);
            // 
            // Btn_Ajout
            // 
            this.Btn_Ajout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_Ajout.Location = new System.Drawing.Point(535, 32);
            this.Btn_Ajout.Name = "Btn_Ajout";
            this.Btn_Ajout.Size = new System.Drawing.Size(114, 27);
            this.Btn_Ajout.TabIndex = 5;
            this.Btn_Ajout.Text = "Ajouter";
            this.Btn_Ajout.UseVisualStyleBackColor = false;
            this.Btn_Ajout.Click += new System.EventHandler(this.Btn_Ajout_Click);
            // 
            // Btn_Nouveau
            // 
            this.Btn_Nouveau.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.Btn_Nouveau.Location = new System.Drawing.Point(365, 50);
            this.Btn_Nouveau.Name = "Btn_Nouveau";
            this.Btn_Nouveau.Size = new System.Drawing.Size(114, 27);
            this.Btn_Nouveau.TabIndex = 4;
            this.Btn_Nouveau.Text = "Nouveau";
            this.Btn_Nouveau.UseVisualStyleBackColor = false;
            this.Btn_Nouveau.Click += new System.EventHandler(this.Btn_Nouveau_Click);
            // 
            // Txt_Mot
            // 
            this.Txt_Mot.Location = new System.Drawing.Point(118, 52);
            this.Txt_Mot.Name = "Txt_Mot";
            this.Txt_Mot.Size = new System.Drawing.Size(232, 22);
            this.Txt_Mot.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Mot :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Défintion :";
            // 
            // Txt_Def
            // 
            this.Txt_Def.Location = new System.Drawing.Point(118, 97);
            this.Txt_Def.Name = "Txt_Def";
            this.Txt_Def.Size = new System.Drawing.Size(379, 94);
            this.Txt_Def.TabIndex = 0;
            this.Txt_Def.Text = "";
            // 
            // Mots
            // 
            this.Mots.HeaderText = "Mots";
            this.Mots.MinimumWidth = 6;
            this.Mots.Name = "Mots";
            this.Mots.Width = 125;
            // 
            // Definitions
            // 
            this.Definitions.HeaderText = "Definitions";
            this.Definitions.MinimumWidth = 6;
            this.Definitions.Name = "Definitions";
            this.Definitions.Width = 125;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Mot)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView Dg_Mot;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button Btn_Vider;
        private System.Windows.Forms.Button Btn_Supprimer;
        private System.Windows.Forms.Button Btn_Recherche;
        private System.Windows.Forms.Button Btn_Ajout;
        private System.Windows.Forms.Button Btn_Nouveau;
        private System.Windows.Forms.TextBox Txt_Mot;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox Txt_Def;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mots;
        private System.Windows.Forms.DataGridViewTextBoxColumn Definitions;
    }
}

