﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tp2_ex_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Dictionary<string, string> Dict_Def = new Dictionary<string, string>();
        private void Btn_Nouveau_Click(object sender, EventArgs e)
        {
            Txt_Mot.Clear();
            Txt_Def.Clear();
            Txt_Mot.Focus();
        }
        private void Afficher()
        {
            Dg_Mot.Rows.Clear();
            foreach (var entry in Dict_Def)
            {
                Dg_Mot.Rows.Add(entry.Key, entry.Value);
            }
        }

        private void Btn_Vider_Click(object sender, EventArgs e)
        {
            Dict_Def.Clear();
            Dg_Mot.Rows.Clear();
            Txt_Mot.Clear();
            Txt_Def.Clear();
        }

        private void Btn_Ajout_Click(object sender, EventArgs e)
        {

            string mot = Txt_Mot.Text.Trim();
            string definition = Txt_Def.Text.Trim();

            if (!string.IsNullOrEmpty(mot) && !string.IsNullOrEmpty(definition))
            {
                if (!Dict_Def.ContainsKey(mot))
                {
                    Dict_Def.Add(mot, definition);
                    Afficher();
                }
                else
                {
                    MessageBox.Show("Le mot existe déjà dans le dictionnaire.");
                }
            }
            else
            {
                MessageBox.Show("Veuillez saisir un mot et une définition.");
            }

        }

        private void Btn_Recherche_Click(object sender, EventArgs e)
        {
            string mot = Txt_Mot.Text.Trim();
            if (! string.IsNullOrEmpty(mot))
            {
                if (Dict_Def.ContainsKey(mot))
                {
                    Txt_Def.Text = Dict_Def[mot];
                }
                else
                {
                    MessageBox.Show("n'existe pas !! ");
                }
            }
        }

        private void Btn_Supprimer_Click(object sender, EventArgs e)
        {
            string mot = Txt_Mot.Text.Trim();
            if (!string.IsNullOrEmpty(mot))
            {
                if (Dict_Def.ContainsKey(mot))
                {
                    Dict_Def.Remove(mot);
                    Afficher();
                    Txt_Mot.Clear();
                    Txt_Def.Clear();
                }
                else
                {
                    MessageBox.Show("Le mot n'existe pas dans le dictionnaire.");
                }
            }
            else
            {
                MessageBox.Show("Veuillez saisir un mot pour la suppression.");
            }
        }
    }
}
