﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using tp4.ADO;

namespace tp4
{
    public partial class FMenu : Form
    {
        public FMenu()
        {
            InitializeComponent();
        }

        private void FMenu_Load(object sender, EventArgs e)
        {
            Connexion.Ouvrir();
            MessageBox.Show(Connexion.cn.State.ToString());
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            FListe_Cl f = new FListe_Cl();
            f.ShowDialog();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {

        }
    }
}
