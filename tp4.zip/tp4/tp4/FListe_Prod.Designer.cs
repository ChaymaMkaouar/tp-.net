﻿namespace tp4
{
    partial class FListe_Prod
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Txt_Ref = new System.Windows.Forms.TextBox();
            this.Txt_Desig = new System.Windows.Forms.TextBox();
            this.Cmb_Categ = new System.Windows.Forms.ComboBox();
            this.Dg_Prod = new System.Windows.Forms.DataGridView();
            this.Ref_Prod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Desig_Prod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Categ_Prod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrixV_Prod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Qte_Stock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vider = new System.Windows.Forms.PictureBox();
            this.modifier = new System.Windows.Forms.PictureBox();
            this.supprimer = new System.Windows.Forms.PictureBox();
            this.ajouter = new System.Windows.Forms.PictureBox();
            this.rechercher = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Prod)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vider)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.modifier)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supprimer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ajouter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rechercher)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Liste des Produits";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Référence";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(270, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Désignation";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(555, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Catégorie";
            // 
            // Txt_Ref
            // 
            this.Txt_Ref.Location = new System.Drawing.Point(94, 80);
            this.Txt_Ref.Name = "Txt_Ref";
            this.Txt_Ref.Size = new System.Drawing.Size(170, 22);
            this.Txt_Ref.TabIndex = 4;
            // 
            // Txt_Desig
            // 
            this.Txt_Desig.Location = new System.Drawing.Point(355, 81);
            this.Txt_Desig.Name = "Txt_Desig";
            this.Txt_Desig.Size = new System.Drawing.Size(170, 22);
            this.Txt_Desig.TabIndex = 5;
            // 
            // Cmb_Categ
            // 
            this.Cmb_Categ.FormattingEnabled = true;
            this.Cmb_Categ.Location = new System.Drawing.Point(627, 81);
            this.Cmb_Categ.Name = "Cmb_Categ";
            this.Cmb_Categ.Size = new System.Drawing.Size(151, 24);
            this.Cmb_Categ.TabIndex = 6;
            // 
            // Dg_Prod
            // 
            this.Dg_Prod.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dg_Prod.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Ref_Prod,
            this.Desig_Prod,
            this.Categ_Prod,
            this.PrixV_Prod,
            this.Qte_Stock});
            this.Dg_Prod.Location = new System.Drawing.Point(121, 162);
            this.Dg_Prod.Name = "Dg_Prod";
            this.Dg_Prod.RowHeadersWidth = 51;
            this.Dg_Prod.RowTemplate.Height = 24;
            this.Dg_Prod.Size = new System.Drawing.Size(638, 260);
            this.Dg_Prod.TabIndex = 11;
            // 
            // Ref_Prod
            // 
            this.Ref_Prod.HeaderText = "Ref_Prod";
            this.Ref_Prod.MinimumWidth = 6;
            this.Ref_Prod.Name = "Ref_Prod";
            this.Ref_Prod.Width = 125;
            // 
            // Desig_Prod
            // 
            this.Desig_Prod.HeaderText = "Desig_Prod";
            this.Desig_Prod.MinimumWidth = 6;
            this.Desig_Prod.Name = "Desig_Prod";
            this.Desig_Prod.Width = 125;
            // 
            // Categ_Prod
            // 
            this.Categ_Prod.HeaderText = "Categ_Prod";
            this.Categ_Prod.MinimumWidth = 6;
            this.Categ_Prod.Name = "Categ_Prod";
            this.Categ_Prod.Width = 125;
            // 
            // PrixV_Prod
            // 
            this.PrixV_Prod.HeaderText = "PrixV_Prod";
            this.PrixV_Prod.MinimumWidth = 6;
            this.PrixV_Prod.Name = "PrixV_Prod";
            this.PrixV_Prod.Width = 125;
            // 
            // Qte_Stock
            // 
            this.Qte_Stock.HeaderText = "Qte_Stock";
            this.Qte_Stock.MinimumWidth = 6;
            this.Qte_Stock.Name = "Qte_Stock";
            this.Qte_Stock.Width = 125;
            // 
            // vider
            // 
            this.vider.Image = global::tp4.Properties.Resources._5366903;
            this.vider.Location = new System.Drawing.Point(802, 80);
            this.vider.Name = "vider";
            this.vider.Size = new System.Drawing.Size(51, 46);
            this.vider.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.vider.TabIndex = 12;
            this.vider.TabStop = false;
            // 
            // modifier
            // 
            this.modifier.Image = global::tp4.Properties.Resources._3082134_200;
            this.modifier.Location = new System.Drawing.Point(24, 377);
            this.modifier.Name = "modifier";
            this.modifier.Size = new System.Drawing.Size(51, 46);
            this.modifier.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.modifier.TabIndex = 10;
            this.modifier.TabStop = false;
            // 
            // supprimer
            // 
            this.supprimer.Image = global::tp4.Properties.Resources._3405244;
            this.supprimer.Location = new System.Drawing.Point(24, 307);
            this.supprimer.Name = "supprimer";
            this.supprimer.Size = new System.Drawing.Size(51, 46);
            this.supprimer.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.supprimer.TabIndex = 9;
            this.supprimer.TabStop = false;
            // 
            // ajouter
            // 
            this.ajouter.Image = global::tp4.Properties.Resources._228122;
            this.ajouter.Location = new System.Drawing.Point(24, 233);
            this.ajouter.Name = "ajouter";
            this.ajouter.Size = new System.Drawing.Size(51, 46);
            this.ajouter.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ajouter.TabIndex = 8;
            this.ajouter.TabStop = false;
            // 
            // rechercher
            // 
            this.rechercher.Image = global::tp4.Properties.Resources._9349901;
            this.rechercher.Location = new System.Drawing.Point(24, 162);
            this.rechercher.Name = "rechercher";
            this.rechercher.Size = new System.Drawing.Size(51, 46);
            this.rechercher.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.rechercher.TabIndex = 7;
            this.rechercher.TabStop = false;
            // 
            // FListe_Prod
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(871, 450);
            this.Controls.Add(this.vider);
            this.Controls.Add(this.Dg_Prod);
            this.Controls.Add(this.modifier);
            this.Controls.Add(this.supprimer);
            this.Controls.Add(this.ajouter);
            this.Controls.Add(this.rechercher);
            this.Controls.Add(this.Cmb_Categ);
            this.Controls.Add(this.Txt_Desig);
            this.Controls.Add(this.Txt_Ref);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FListe_Prod";
            this.Text = "FListe_Prod";
            ((System.ComponentModel.ISupportInitialize)(this.Dg_Prod)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vider)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.modifier)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supprimer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ajouter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rechercher)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Txt_Ref;
        private System.Windows.Forms.TextBox Txt_Desig;
        private System.Windows.Forms.ComboBox Cmb_Categ;
        private System.Windows.Forms.PictureBox rechercher;
        private System.Windows.Forms.PictureBox ajouter;
        private System.Windows.Forms.PictureBox supprimer;
        private System.Windows.Forms.PictureBox modifier;
        private System.Windows.Forms.DataGridView Dg_Prod;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ref_Prod;
        private System.Windows.Forms.DataGridViewTextBoxColumn Desig_Prod;
        private System.Windows.Forms.DataGridViewTextBoxColumn Categ_Prod;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrixV_Prod;
        private System.Windows.Forms.DataGridViewTextBoxColumn Qte_Stock;
        private System.Windows.Forms.PictureBox vider;
    }
}