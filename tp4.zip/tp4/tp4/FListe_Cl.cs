﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using tp4.ADO;

namespace tp4
{
    public partial class FListe_Cl : Form
    {
        public FListe_Cl()
        {
            InitializeComponent();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void FListe_Cl_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ClientADO.Liste_Client();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

            if (ClientADO.Existe_Client(Int64.Parse(textBox1.Text)))
            {
                MessageBox.Show(this, "\n\nClient déjà existant", "attention!!!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                Client C = new Client
                {
                    Cin_Cl = Int64.Parse(textBox1.Text),
                    Nom_Cl = textBox2.Text,
                    Pren_Cl = textBox3.Text,
                    Ville_Cl = textBox4.Text,
                    Tel_Cl = Int64.Parse(textBox5.Text),
                };
                ClientADO CA = new ClientADO();
                CA.Inserer(C);
                dataGridView1.DataSource = ClientADO.Liste_Client();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            int ind = dataGridView1.CurrentRow.Index;
            textBox1.Text = dataGridView1[0, ind].Value.ToString();
            textBox2.Text = dataGridView1[1, ind].Value.ToString();
            textBox3.Text = dataGridView1[2, ind].Value.ToString();
            textBox4.Text = dataGridView1[3, ind].Value.ToString();
            textBox5.Text = dataGridView1[4, ind].Value.ToString();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Client C = new Client
            {
                Cin_Cl = Int64.Parse(textBox1.Text),
                Nom_Cl = textBox2.Text,
                Pren_Cl = textBox3.Text,
                Ville_Cl = textBox4.Text,
                Tel_Cl = Int64.Parse(textBox5.Text),
            };
            ClientADO CA = new ClientADO();
            CA.Modifier(C);
            dataGridView1.DataSource = ClientADO.Liste_Client();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            DialogResult rep = MessageBox.Show(this, "\n\nVoulez vous confirmer la suppression ", "Suppression", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (rep == DialogResult.Yes)
            {
                ClientADO CA = new ClientADO();
                CA.Supprimer(Int64.Parse(textBox1.Text));
                dataGridView1.DataSource = ClientADO.Liste_Client();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            DataTable dtc = ClientADO.Liste_Client(Int64.Parse(textBox1.Text));
            if (dtc.Rows.Count == 0)
            {
                MessageBox.Show(this, "Client inexistant");
            }
            else
            {
                textBox2.Text = dtc.Rows[0][1].ToString();
                textBox3.Text = dtc.Rows[0][2].ToString();
                textBox4.Text = dtc.Rows[0][3].ToString();
                textBox5.Text = dtc.Rows[0][1].ToString();
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
