﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tp3
{
    public class Mouvements
    {
        DateTime dateop;
        string typop;
        double montant;

        public Mouvements(DateTime dop, string type, double mt)
        {
            dateop = dop;
            typop = type;
            montant = mt;
        }
        public string typ_oper
        {
            get { return typop; }
            set { typop = value; }
        }
        public DateTime date_op
        {
            get { return dateop; }
            set { dateop = value; }
        }
        public double montant_op
        {
            get { return montant; }
            set { montant = value; }
        }




    }
}
