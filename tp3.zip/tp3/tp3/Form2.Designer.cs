﻿namespace tp3
{
    partial class FCompte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Numéro = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Txtnumcompte = new System.Windows.Forms.TextBox();
            this.Txttitulaire = new System.Windows.Forms.TextBox();
            this.Txt_Valid = new System.Windows.Forms.TextBox();
            this.Btn_Valid = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Btn_Valid);
            this.groupBox1.Controls.Add(this.Txt_Valid);
            this.groupBox1.Controls.Add(this.Txttitulaire);
            this.groupBox1.Controls.Add(this.Txtnumcompte);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.Numéro);
            this.groupBox1.Location = new System.Drawing.Point(41, 38);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(696, 364);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Création Nouveau Compte";
            // 
            // Numéro
            // 
            this.Numéro.AutoSize = true;
            this.Numéro.Location = new System.Drawing.Point(67, 69);
            this.Numéro.Name = "Numéro";
            this.Numéro.Size = new System.Drawing.Size(55, 16);
            this.Numéro.TabIndex = 0;
            this.Numéro.Text = "Numéro";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(67, 153);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Titulaire";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(67, 235);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Solde";
            // 
            // Txtnumcompte
            // 
            this.Txtnumcompte.Location = new System.Drawing.Point(163, 63);
            this.Txtnumcompte.Name = "Txtnumcompte";
            this.Txtnumcompte.Size = new System.Drawing.Size(331, 22);
            this.Txtnumcompte.TabIndex = 3;
            // 
            // Txttitulaire
            // 
            this.Txttitulaire.Location = new System.Drawing.Point(163, 147);
            this.Txttitulaire.Name = "Txttitulaire";
            this.Txttitulaire.Size = new System.Drawing.Size(331, 22);
            this.Txttitulaire.TabIndex = 4;
            // 
            // Txt_Valid
            // 
            this.Txt_Valid.Location = new System.Drawing.Point(163, 235);
            this.Txt_Valid.Name = "Txt_Valid";
            this.Txt_Valid.Size = new System.Drawing.Size(331, 22);
            this.Txt_Valid.TabIndex = 5;
            // 
            // Btn_Valid
            // 
            this.Btn_Valid.Location = new System.Drawing.Point(303, 307);
            this.Btn_Valid.Name = "Btn_Valid";
            this.Btn_Valid.Size = new System.Drawing.Size(75, 23);
            this.Btn_Valid.TabIndex = 6;
            this.Btn_Valid.Text = "Valider";
            this.Btn_Valid.UseVisualStyleBackColor = true;
            // 
            // FCompte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Name = "FCompte";
            this.Text = "Form2";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Btn_Valid;
        private System.Windows.Forms.TextBox Txt_Valid;
        private System.Windows.Forms.TextBox Txttitulaire;
        private System.Windows.Forms.TextBox Txtnumcompte;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Numéro;
    }
}