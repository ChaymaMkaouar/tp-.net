﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tp1_ex2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            string s = "";
            if (radioButton1.Checked)
            {
                s = "Homme";
            }
            else
            {
                s = "Femme";
            }
            string ch = "votre nom est " + textBox1.Text +" "+ textBox3.Text + "\n" + "vous étes née le" + dateTimePicker1.Value.ToString() + "\n" + "vous étes "+s;
            MessageBox.Show(ch);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult resultat = File_Photo.ShowDialog();
            if (resultat == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(File_Photo.FileName);
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            DialogResult resultat = Col_Form.ShowDialog();
            if (resultat == DialogResult.OK)
            {
                this.BackColor = Col_Form.Color;
            }
        }
    }
}
