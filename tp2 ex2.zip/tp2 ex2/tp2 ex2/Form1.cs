﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tp2_ex2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Queue<int> QVolailles = new Queue<int>();
        Queue<int> QViandes = new Queue<int>();
        int Tick_Vol = 1;
        int Tick_Viand = 1;
        private void Afficher_Volailles()
        {
            listBox1.Items.Clear();
            foreach(int ticket in QVolailles)
            {
                listBox1.Items.Add(ticket);
            }
        }

        private void Afficher_Viandes()
        {
            listBox2.Items.Clear();
            foreach (int ticket in QViandes)
            {
                listBox2.Items.Add(ticket);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (QVolailles.Count > 0)
            {
                QVolailles.Dequeue();
                Afficher_Volailles();
            }
            else
            {
                MessageBox.Show("La file d'attente des Volailles est vide.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                QVolailles.Enqueue(Tick_Vol);
                Tick_Vol++;
                Afficher_Volailles();
            }
            else if (radioButton2.Checked)
            {
                QViandes.Enqueue(Tick_Viand);
                Tick_Viand++;
                Afficher_Viandes();
            }
            else
            {
                MessageBox.Show("Veuillez choisir une option (Volailles ou Viandes).");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (QViandes.Count > 0)
            {
                QViandes.Dequeue();
                Afficher_Viandes();
            }
            else
            {
                MessageBox.Show("La file d'attente des Viandes est vide.");
            }
        }
    }
    }

