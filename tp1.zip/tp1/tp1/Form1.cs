﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //button add
            if (string.IsNullOrEmpty(textBox1.Text) ||string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Attention:zone valide");
            }
            else
            {
                try
                {
                    int op1 = Convert.ToInt32(textBox1.Text);
                    int op2 = Convert.ToInt32(textBox2.Text);
                    int res = op1 + op2;
                    textBox3.Text = textBox1.Text + "+" + textBox2.Text;
                    textBox4.Text = res.ToString();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }


        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Text = "";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //button add
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Attention:zone valide");
            }
            else
            {
                try
                {
                    int op1 = Convert.ToInt32(textBox1.Text);
                    int op2 = Convert.ToInt32(textBox2.Text);
                    int res = op1 - op2;
                    textBox3.Text = textBox1.Text + "-" + textBox2.Text;
                    textBox4.Text = res.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //button add
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Attention:zone valide");
            }
            else
            {
                try
                {
                    int op1 = Convert.ToInt32(textBox1.Text);
                    int op2 = Convert.ToInt32(textBox2.Text);
                    int res = op1 * op2;
                    textBox3.Text = textBox1.Text + "*" + textBox2.Text;
                    textBox4.Text = res.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //button add
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Attention:zone valide");
            }
            else
            {
                try
                {
                    int op1 = Convert.ToInt32(textBox1.Text);
                    int op2 = Convert.ToInt32(textBox2.Text);
                    int res = op1 / op2;
                    textBox3.Text = textBox1.Text + "/" + textBox2.Text;
                    textBox4.Text = res.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //button add
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Attention:zone valide");
            }
            else
            {
                try
                {
                    int op1 = Convert.ToInt32(textBox1.Text);
                    int op2 = Convert.ToInt32(textBox2.Text);
                    int res = op1 % op2;
                    textBox3.Text = textBox1.Text + "%" + textBox2.Text;
                    textBox4.Text = res.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}
