﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox2.Text))
            {
                float valeurRecherchee;
                if (float.TryParse(textBox2.Text, out valeurRecherchee))
                {

                    if (LIST_Int.Contains(valeurRecherchee))
                    {
                        MessageBox.Show("La valeur existe dans la liste.");
                    }
                    else
                    {
                        MessageBox.Show("La valeur n'existe pas dans la liste.");
                    }
                }
                else
                {
                    MessageBox.Show("Veuillez saisir une valeur valide.");
                }
            }
            else
            {
                MessageBox.Show("Veuillez saisir une valeur à rechercher.");
            }
        }
    
        List<float> LIST_Int = new List<float>();
        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("note vide!!");
            }
            else
            {
                try
                {
                    float note = float.Parse(textBox1.Text);
                    if (note<0 || note>20)
                    {
                        MessageBox.Show("note non valide !!! ");
                    }
                    else
                    {
                        LIST_Int.Add(note);
                        Affiche_liste();
                        textBox1.Clear();
                        textBox1.Focus();
                    }
                }catch(Exception ex)
                { 
                    MessageBox.Show(ex.Message);
                }
            }
        }
        private void Affiche_liste()
        {
            lis_ent.Items.Clear();
            foreach(float n in LIST_Int)
            {
                lis_ent.Items.Add(n);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (lis_ent.SelectedIndex != -1)
            {

                LIST_Int.RemoveAt(lis_ent.SelectedIndex);

                Affiche_liste();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (!radioButton1.Checked && !radioButton2.Checked && !radioButton3.Checked)
                MessageBox.Show("Vous devez choisir un critère de suppression !");
            else
            if (radioButton1.Checked && LIST_Int.Exists(x => x > 10))
                LIST_Int.RemoveAll(x => x > 10);
            else
             if (radioButton2.Checked && LIST_Int.Exists(x => x < 10))
                LIST_Int.RemoveAll(x => x < 10);
            else
        if (radioButton3.Checked && LIST_Int.Exists(x => x == 10))
                LIST_Int.RemoveAll(x => x == 10);
            Affiche_liste();
        }

        private void button8_Click(object sender, EventArgs e)
        {

            String s = "";
            foreach (float x in LIST_Int)
                s = s + x.ToString() + " ";
            textBox3.Text = s;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LIST_Int.Sort();
            Affiche_liste();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LIST_Int.Clear();
            Affiche_liste();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LIST_Int.Reverse();
            Affiche_liste();
        }
    }
}
